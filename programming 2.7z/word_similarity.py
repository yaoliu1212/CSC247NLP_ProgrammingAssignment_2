import nltk
from nltk import sent_tokenize
from nltk import word_tokenize
import gensim
from gensim.models import Word2Vec
from gensim.models.phrases import Phrases, Phraser
import gensim.downloader as api
import argparse

# load word2vec model
wv = api.load('word2vec-google-news-300')
# model = gensim.models.Word2Vec()
# model.wv.most_similar(positive = w1)

# get the most similar word
def maxSimilarityWord(word, outputList):
    maxSimWord = ''
    maxSimScore = 0
    for i in outputList:
        score = wv.similarity(word, i)
        if score >= maxSimScore:
            maxSimWord = i
            maxSimScore = score
    return maxSimWord

# read arguments
parser = argparser.ArgumentParser()
parser.add_argument('input', type= str, default = 'input.txt')
parser.add_argument('output', type= str, default = 'output.txt')
args = parser.parse_args()
# open input file
inputFilename = str(args.input)
def openFile(filename):
    with open(filename) as f:
        inputList = f.readlines()
    return inputList

inputList = openFile(inputFilename)
output = []
# open corpus file
with open('word_similarity.txt') as s:
    outputList = s.readlines()
# get the most similar word for each input word
# store result in output list
for i in inputList:
    temp = maxSimilarityWord(i, outputList)
    output.append(temp)
# create output file: input word/phrase + most similar word/phrase
outputFilename = str(args.output)
with open(outputFilename,'w') as f:
    for i in range(len(inputList)):
        f.write(inputList[i])
        f.write(" ")
        f.write(outputList[i])
        f.write("\n")
